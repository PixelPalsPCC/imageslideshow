# imageslideshow
#this program creates a slide show of images #if the data attribute on the image tag is "sequential", then images are displayed one after another, otherwise a random image will be displayed
